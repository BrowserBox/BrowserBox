#!/usr/bin/env bash

./deploy-scripts/run_docker.sh 9999 localhost user@hostname.tld
