<h1>BrowserBox Azure Template</h1>

Create a [BrowserBox](https://github.com/BrowserBox/BrowserBox) virtual machine, enabling secure Remote Browser Isolation.
<br><img src=https://dosyago.com/favicon.ico>

By providing your email address you agree to [our terms](https://dosyago.com/terms.txt), [our privacy policy](https://dosyago.com/privacy.txt) and the LetsEncrypt terms. 

We also use your email address to send you your BrowserBox Login Link once your browser is created.

**Steps**:

- Pick your nearest location.
- Fill out your email

**Optional steps:**

- Change machine size and operating system
- Set up SSH Access
- 
