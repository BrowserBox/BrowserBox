This directory contains a snapshot of the terms and privacy policy of imgbot to guard against any legal issues with utilizing their robot contribution (which makes images smaller in size for faster downloads). 

The terms clearly state imgbot retains no rights to any content. And that its contributions are free for open source projects. Cool.
