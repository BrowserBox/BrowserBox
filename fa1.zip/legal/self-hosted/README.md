# BrowserBox Self-Hosted Legal Agreement

By continuing to self-host BrowserBox you agree to [our terms](https://dosyago.com/terms.txt), [our license](https://github.com/BrowserBox/BrowserBox/blob/boss/LICENSE.md), and [our privacy policy](https://dosyago.com/privacy.txt). You also agree that you are responsible for all charges you incur on Cloud and other providers for your use of our Software when you self-host. You are solely liable for any damages that may result. The software is provided as-is and, beyond those reasonable best practices which we strive to employ, it comes with no guarantee of fitness for purpose or security, when you self-host.

For help and support at any time, contact the BrowserBox team at DOSYAGO: browserbox@dosyago.com

