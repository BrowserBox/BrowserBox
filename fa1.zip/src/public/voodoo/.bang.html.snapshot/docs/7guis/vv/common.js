// common for all r submodules
  export const CODE              = ''+Math.random();

