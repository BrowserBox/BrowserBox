class Component extends Base {
  noFindBang = true;
}
