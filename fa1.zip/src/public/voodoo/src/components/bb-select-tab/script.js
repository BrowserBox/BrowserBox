class BBSelectTab extends Base {

}
