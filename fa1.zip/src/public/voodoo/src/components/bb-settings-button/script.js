class BBSettingsButton extends Base {
  constructor() {
    super();
  }

  disconnectedCallback() {
    super.disconnectedCallback();
  }
}
