alert(location.href);
