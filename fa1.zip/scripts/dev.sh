#!/usr/bin/env bash

node --inspect=127.0.0.1:8111 index.js 5002 8002 xxxcookie $USER token2
