//import 'whatwg-fetch';
//import '@babel/polyfill';
import './resize_helper.js';
import './error_catchers.js';
import './prod/setup-service-worker.js';
import './prod/ask-before-unload.js';
