addEventListener('click', click => {
  if ( click.target.matches('button') ) {
    close();
  }
});
