# Assets directory

This contains CORS and CORP enabled assets that can be loaded (say via script tag, or fetch) into
any page (intended to be loaded into pages on the remote browser) for injection etc.

