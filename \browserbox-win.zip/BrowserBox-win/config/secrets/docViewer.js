const SECRET = 'PQIcuD/zPGBShfcrYE0fqCLHgmO1bg==';
export default SECRET;

