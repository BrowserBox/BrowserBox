# Webview API

Ensure you set 

```bash
export ALLOWED_EMBEDDING_ORIGINS="https://site-that-serves-the-page-using-the-webview.example.com https://other-site.you-will-embed.browserbox-on.com"
```

Before running `bbx run` or equivalent run commands.
