# Note

On this day

The 23rd of January Two Thousand Twenty Two

I, Cris DOSAYGO

Founder of the Dosyago Corporation

Creator of the BrowserBox series of projects

do hereby declare that I am flattening the

git history of this project at the point of 

the commit where this file was created.

Henceforth, I shall be using a 

fully-flattened copy of VFPro for further development

And the repository containing the entire project history

shall be archived.

# Update July 31 2022

Prior to the above flattening development of BB (formerly VFPro, ViewFinder and other names)

was in continued development for over three years (since the end of 2018, approximately October or November 2018).

One of the earliest projects (on which this code was based) was called zanj: https://gitlab.com/dosycorp/zanj [private repository]

