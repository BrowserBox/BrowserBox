#!/usr/bin/env bash

rm public/bundle_image*
rm public/bundle_start*
rm public/meta_bundle*
