#!/usr/bin/env bash

npm i --save-dev whatwg-fetch
